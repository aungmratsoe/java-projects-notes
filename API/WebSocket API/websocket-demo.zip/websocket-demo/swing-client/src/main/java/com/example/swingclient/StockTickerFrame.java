package com.example.swingclient;

import javax.swing.*;
import java.awt.*;
import java.net.URI;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StockTickerFrame extends JFrame implements StockPriceClient.PriceUpdateListener {

    private final JLabel priceLabel = new JLabel("Price: --", SwingConstants.CENTER);
    private final JLabel statusLabel = new JLabel("Disconnected", SwingConstants.CENTER);
    private final JTextArea logArea = new JTextArea(10, 40);
    private final JButton connectButton = new JButton("Connect");
    private final JButton disconnectButton = new JButton("Disconnect");
    private final JTextField serverUrlField = new JTextField("ws://localhost:8080/stock-stream", 30);

    private StockPriceClient wsClient;

    // Minimal regex-based JSON value extractor (demo ရိုးရိုးအတွက်ပါ — dependency လျှော့ချထားတယ်)
    private static final Pattern PRICE_PATTERN = Pattern.compile("\"price\":([\\d.]+)");
    private static final Pattern TYPE_PATTERN = Pattern.compile("\"type\":\"(\\w+)\"");

    public StockTickerFrame() {
        super("WebSocket Stock Ticker (Swing Client)");
        buildUi();
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                disconnect();
                dispose();
                System.exit(0);
            }
        });
        setSize(500, 420);
        setLocationRelativeTo(null);
    }

    private void buildUi() {
        setLayout(new BorderLayout(10, 10));

        // --- Top: connection controls ---
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topPanel.add(new JLabel("Server URL:"));
        topPanel.add(serverUrlField);
        topPanel.add(connectButton);
        topPanel.add(disconnectButton);
        disconnectButton.setEnabled(false);
        add(topPanel, BorderLayout.NORTH);

        // --- Center: price display ---
        JPanel centerPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        priceLabel.setFont(new Font("SansSerif", Font.BOLD, 32));
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        centerPanel.add(priceLabel);
        centerPanel.add(statusLabel);
        add(centerPanel, BorderLayout.CENTER);

        // --- Bottom: raw message log ---
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        add(new JScrollPane(logArea), BorderLayout.SOUTH);

        connectButton.addActionListener(e -> connect());
        disconnectButton.addActionListener(e -> disconnect());
    }

    private void connect() {
        try {
            URI uri = new URI(serverUrlField.getText().trim());
            wsClient = new StockPriceClient(uri, this);
            statusLabel.setText("Connecting...");
            connectButton.setEnabled(false);
            wsClient.connect(); // asynchronous connect — background thread မှာ run
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Invalid URL: " + ex.getMessage(),
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void disconnect() {
        if (wsClient != null && wsClient.isOpen()) {
            wsClient.close();
        }
    }

    private String timestamp() {
        return LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    private void log(String text) {
        logArea.append("[" + timestamp() + "] " + text + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    // ==== StockPriceClient.PriceUpdateListener callbacks ====
    // ဒီ method တွေဟာ StockPriceClient ထဲမှာ invokeLater() နဲ့ ခေါ်ထားတာမို့
    // EDT ပေါ်မှာပဲ run ပါတယ် — UI update လုပ်လို့ လုံးဝ safe ပါတယ်

    @Override
    public void onConnected() {
        statusLabel.setText("Connected ✓");
        connectButton.setEnabled(false);
        disconnectButton.setEnabled(true);
        log("Connected to server");
    }

    @Override
    public void onPriceUpdate(String rawMessage) {
        log("Received: " + rawMessage);

        Matcher typeMatcher = TYPE_PATTERN.matcher(rawMessage);
        String type = typeMatcher.find() ? typeMatcher.group(1) : "unknown";

        if ("price".equals(type)) {
            Matcher priceMatcher = PRICE_PATTERN.matcher(rawMessage);
            if (priceMatcher.find()) {
                String price = priceMatcher.group(1);
                priceLabel.setText("$" + price);
            }
        }
    }

    @Override
    public void onDisconnected() {
        statusLabel.setText("Disconnected");
        connectButton.setEnabled(true);
        disconnectButton.setEnabled(false);
        log("Disconnected from server");
    }

    @Override
    public void onError(String error) {
        statusLabel.setText("Error");
        connectButton.setEnabled(true);
        disconnectButton.setEnabled(false);
        log("ERROR: " + error);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StockTickerFrame().setVisible(true));
    }
}
