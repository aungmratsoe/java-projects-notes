package com.example.swingclient;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import javax.swing.SwingUtilities;
import java.net.URI;

public class StockPriceClient extends WebSocketClient {

    public interface PriceUpdateListener {
        void onPriceUpdate(String rawMessage);
        void onConnected();
        void onDisconnected();
        void onError(String error);
    }

    private final PriceUpdateListener listener;

    public StockPriceClient(URI serverUri, PriceUpdateListener listener) {
        super(serverUri);
        this.listener = listener;
    }

    @Override
    public void onOpen(ServerHandshake handshake) {
        // ဒီ callback က WebSocket ကိုယ်ပိုင် thread ပေါ်မှာ run ပါတယ်
        // Swing UI ကို touch မလုပ်ခင် invokeLater နဲ့ EDT ဆီ ပြန်ပို့ရပါတယ်
        SwingUtilities.invokeLater(listener::onConnected);
    }

    @Override
    public void onMessage(String message) {
        SwingUtilities.invokeLater(() -> listener.onPriceUpdate(message));
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        SwingUtilities.invokeLater(listener::onDisconnected);
    }

    @Override
    public void onError(Exception ex) {
        SwingUtilities.invokeLater(() -> listener.onError(ex.getMessage()));
    }
}
