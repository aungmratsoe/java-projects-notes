# WebSocket End-to-End Demo (Spring Boot Server + Swing Client)

ဒီ project မှာ folder နှစ်ခု ပါဝင်ပါတယ်:

- **`server/`** — Spring Boot WebSocket server (3 စက္ကန့်တစ်ခါ fake stock price broadcast လုပ်ပေးတယ်)
- **`swing-client/`** — Java Swing desktop app (server ကို connect လုပ်ပြီး live price ကို JLabel မှာ ပြတယ်)

## လိုအပ်ချက်များ

- JDK 17 ဒါမှမဟုတ် အထက်
- Maven 3.6+
- Internet connection (dependency download လုပ်ဖို့ — Spring Boot, Java-WebSocket library)

## Step 1 — Server ကို Run ခြင်း

Terminal တစ်ခုဖွင့်ပြီး:

```bash
cd server
mvn spring-boot:run
```

Server successfully startup ဖြစ်ရင် console မှာ ဒီလို မြင်ရပါလိမ့်မယ်:

```
=================================================
 WebSocket server started!
 Endpoint: ws://localhost:8080/stock-stream
=================================================
```

Server က `ws://localhost:8080/stock-stream` မှာ listen လုပ်နေပါပြီ။ **ဒီ terminal ကို ပိတ်မထားပါနဲ့** — server run နေရမှ client က connect လုပ်လို့ရမှာပါ။

## Step 2 — Swing Client ကို Run ခြင်း

Terminal **အသစ်တစ်ခု** ဖွင့်ပြီး:

```bash
cd swing-client
mvn clean package
java -jar target/swing-ws-client-1.0.0.jar
```

ဒါမှမဟုတ် NetBeans/IntelliJ ထဲကနေ `swing-client` folder ကို Maven project အဖြစ် open လုပ်ပြီး
`StockTickerFrame.java` ရဲ့ `main()` method ကို directly Run လုပ်လည်း ရပါတယ်.

## Step 3 — Test လုပ်ခြင်း

1. Swing window ပွင့်လာရင် **Server URL** field မှာ `ws://localhost:8080/stock-stream` ဆိုတာ default ပါပြီးသားပါ
2. **Connect** button ကို နှိပ်ပါ
3. "Connected ✓" ပြရင် connection အောင်မြင်ပါပြီ
4. 3 စက္ကန့်တစ်ခါ server ကနေ fake AAPL stock price ကို push လုပ်ပေးမှာဖြစ်ပြီး၊ Swing window ထဲက price label က auto update ဖြစ်သွားပါလိမ့်မယ်
5. အောက်ဘက်က log area မှာ raw JSON message တွေကို timestamp နဲ့တကွ မြင်ရပါလိမ့်မယ်
6. **Disconnect** button နဲ့ connection ကို ပိတ်လို့ရပါတယ်

## Client အများကြီးနဲ့ Test လုပ်ချင်ရင်

Swing client jar ကို terminal အများကြီးကနေ တစ်ချိန်တည်း run ခွင့်ပြုပါတယ်:

```bash
java -jar target/swing-ws-client-1.0.0.jar
```

Window အသစ်တစ်ခုစီမှာ Connect နှိပ်ပြီး connect လုပ်ကြည့်ပါ — server side console မှာ
"Total clients: 2", "Total clients: 3" စသည်ဖြင့် client count တိုးလာတာ တွေ့ရပါလိမ့်မယ်။
ဒါက WebSocket ရဲ့ **broadcast to multiple clients** feature ကို သရုပ်ပြနေတာပါ.

## ဘာတွေ ဖြစ်နေလဲ (Flow အကျဉ်းချုပ်)

```
[Swing Client] --connect--> [Spring WebSocket Server]
[Server] --welcome message--> [Swing Client]
[Server scheduled task, every 3s] --price broadcast--> [All connected Swing Clients]
[Swing Client UI] auto-updates price label (via SwingUtilities.invokeLater)
```

## Troubleshooting

| ပြဿနာ | ဖြေရှင်းနည်း |
|---|---|
| `Connection refused` | Server run နေမနေ စစ်ပါ (`mvn spring-boot:run` terminal ကို ပြန်ကြည့်) |
| Port 8080 already in use | `server/src/main/resources/application.properties` ထဲက `server.port` ကို 8081 စသည်ဖြင့် ပြောင်းပါ၊ client URL ကိုလည်း ကိုက်အောင် ပြောင်းပါ |
| Client window freeze | မဖြစ်သင့်ပါ — connect/message handling အားလုံး SwingUtilities.invokeLater() ကနေ EDT ဆီပြန်ပို့ထားလို့ပါ |
| Maven dependency download မရ | Internet connection စစ်ပါ၊ firewall/proxy ရှိရင် Maven settings.xml ချိန်ညှိရန် လိုနိုင်ပါတယ် |
