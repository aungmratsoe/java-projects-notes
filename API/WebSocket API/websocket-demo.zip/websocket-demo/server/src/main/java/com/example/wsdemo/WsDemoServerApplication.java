package com.example.wsdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

// application.properties မှာ server.port=8080 ဖြစ်နေမယ် (default)
// Run လုပ်ပြီးရင် server က ws://localhost:8080/stock-stream မှာ listen လုပ်ပါလိမ့်မယ်
@SpringBootApplication
@EnableScheduling
public class WsDemoServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(WsDemoServerApplication.class, args);
        System.out.println("=================================================");
        System.out.println(" WebSocket server started!");
        System.out.println(" Endpoint: ws://localhost:8080/stock-stream");
        System.out.println("=================================================");
    }
}
