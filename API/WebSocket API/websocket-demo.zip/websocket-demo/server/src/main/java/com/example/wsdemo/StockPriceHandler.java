package com.example.wsdemo;

import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.util.concurrent.CopyOnWriteArrayList;

public class StockPriceHandler extends TextWebSocketHandler {

    // Connect ထားတဲ့ client (session) အားလုံးကို thread-safe list ထဲ track လုပ်ထားတယ်
    private static final CopyOnWriteArrayList<WebSocketSession> sessions =
            new CopyOnWriteArrayList<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
        System.out.println("[Server] Client connected: " + session.getId()
                + " | Total clients: " + sessions.size());

        // Client ချိတ်ဆက်တာနဲ့ welcome message ချက်ချင်းပို့
        session.sendMessage(new TextMessage("{\"type\":\"welcome\",\"message\":\"Connected to stock stream\"}"));
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        String payload = message.getPayload();
        System.out.println("[Server] Received from " + session.getId() + ": " + payload);

        // ဥပမာ - client က {"action":"subscribe","symbol":"AAPL"} ပို့ရင် acknowledge ပြန်ပို့
        session.sendMessage(new TextMessage("{\"type\":\"ack\",\"message\":\"Received: " + payload + "\"}"));
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        sessions.remove(session);
        System.out.println("[Server] Client disconnected: " + session.getId()
                + " | Total clients: " + sessions.size());
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        System.err.println("[Server] Transport error for " + session.getId() + ": " + exception.getMessage());
        sessions.remove(session);
    }

    // Scheduled broadcaster ကနေ ခေါ်ပြီး client အားလုံးဆီ တစ်ပြိုင်နက်တည်း message ပို့ဖို့
    public static void broadcastToAll(String message) {
        for (WebSocketSession session : sessions) {
            try {
                if (session.isOpen()) {
                    session.sendMessage(new TextMessage(message));
                }
            } catch (Exception e) {
                System.err.println("[Server] Broadcast failed for " + session.getId() + ": " + e.getMessage());
            }
        }
    }

    public static int connectedClientCount() {
        return sessions.size();
    }
}
