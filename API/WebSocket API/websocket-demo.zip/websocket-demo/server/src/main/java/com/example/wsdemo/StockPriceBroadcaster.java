package com.example.wsdemo;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class StockPriceBroadcaster {

    private final Random random = new Random();
    private double lastPrice = 150.00; // AAPL simulated starting price

    // 3 seconds တစ်ခါ run ပြီး connect ထားတဲ့ client အားလုံးဆီ price update push
    @Scheduled(fixedRate = 3000)
    public void pushPriceUpdate() {
        if (StockPriceHandler.connectedClientCount() == 0) {
            return; // client မရှိရင် broadcast မလုပ်တော့ (resource save)
        }

        // Price ကို random small amount တက်/ကျ အောင် simulate
        double change = (random.nextDouble() - 0.5) * 2; // -1.0 ~ +1.0
        lastPrice = Math.max(1.0, lastPrice + change);

        String message = String.format(
                "{\"type\":\"price\",\"symbol\":\"AAPL\",\"price\":%.2f,\"timestamp\":%d}",
                lastPrice, System.currentTimeMillis()
        );

        StockPriceHandler.broadcastToAll(message);
        System.out.println("[Server] Broadcasted: " + message);
    }
}
