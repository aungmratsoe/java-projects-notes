package com.example.wsdemo;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // /stock-stream path ကို StockPriceHandler နဲ့ ချိတ်ဆက်
        // setAllowedOrigins("*") ကို demo/testing အတွက်ပဲ သုံးထားပါတယ်
        // (production မှာ specific domain ပဲ ခွင့်ပြုသင့်ပါတယ်)
        registry.addHandler(new StockPriceHandler(), "/stock-stream")
                .setAllowedOrigins("*");
    }
}
